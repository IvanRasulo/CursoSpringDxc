package com.microcompany.accountsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountsserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
